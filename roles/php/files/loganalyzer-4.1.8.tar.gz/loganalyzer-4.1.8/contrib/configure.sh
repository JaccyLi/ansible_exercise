#!/bin/sh

touch config.php
chmod 666 config.php
